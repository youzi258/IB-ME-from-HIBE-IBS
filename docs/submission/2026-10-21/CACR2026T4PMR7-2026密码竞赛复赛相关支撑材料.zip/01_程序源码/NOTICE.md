# 来源与许可说明

本作品实现文献中的HIBE和IBS算法，以公共接口组合，提供参数选择、完整字节认证、状态管理、紧凑编码、准备复用、实验与演示。论文算法、既有认证转换、第三方原生实现与本作品的工程工作分别说明。

项目代码采用MIT许可，见`01_程序源码/LICENSE`。第三方代码保留原始版权、许可及作者信息，其固定源码和摘要保存在各`UPSTREAM.json`中。包内含以下固定来源：

| 组件 | 固定来源 | 声明所在包内位置 |
|---|---|---|
| LATTE-3 | cqs-technology/latte，18cfbf9a671fca34785583b58ab9f28e3be21a3c | `01_程序源码/src/ibme/hibe/latte/native/upstream/`，原MIT许可；COSAC修复由构建器显式应用 |
| ML-DSA | pq-crystals/dilithium，d35ba3fe5449bee3e6d43e1f296c3ca818bd36be | `01_程序源码/src/ibme/ibs/certified/native/upstream/`，保留原LICENSE与AUTHORS |
| Falcon | 官方Falcon-impl-20211101.zip | `01_程序源码/src/ibme/ibs/certified/falcon_native/upstream/`，保留各源码原MIT声明 |
| LATTE采样研究快照 | 同一LATTE提交中的latte_1/sample_z.c | `01_程序源码/experiments/research/reuse/vendor/latte/`，原MIT许可；不作为生产采样器 |

第三方作者、机构和仓库属于引用来源，不是参赛团队署名。报告中的论文和标准引用保持原文献作者信息。往届作品、无关论文PDF、开发聊天、Git记录、真实私钥和运行状态不属于本支撑包。

当前源码快照、报告摘要和每个附件原件的来源路径由交付清单记录。历史实验绑定其各自执行版本；本次整理没有把原始数据改写为当前源码的新实验。若为匿名提交泛化机器路径，清单将分别保留原件摘要、提交副本摘要和实际处理的字段类别，数值及结果保持原样。

本包提供项目自己的Python安装文件。SageMath、NumPy、cryptography、GMP、MPFR、MPC、OpenSSL、FLINT及编译器由运行环境提供，具体实验版本在对应环境记录中；本包没有将这些环境软件整体再分发。
