# IB-ME 源代码

作品编号 CACR2026T4PMR7。

源代码与测试来自固定公开快照。运行说明见相邻目录 `00_材料说明/运行与演示.md`，安装包见 `05_安装文件/`。主程序在 `src/ibme/`，所调用研究提供者与实验驱动在 `experiments/`，测试在 `tests/`，测试清单在 `ci/`。构建使用 `python -m pip wheel --no-deps --no-build-isolation --no-index .`。Sage 与原生数学依赖由运行环境提供；第三方固定源码及许可随代码保留。
